//
//  TabBasedApplicationApp.swift
//  TabBasedApplication
//
//  Created by Ritika Verma on 18/04/22.
//

import SwiftUI

@main
struct TabBasedApplicationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
