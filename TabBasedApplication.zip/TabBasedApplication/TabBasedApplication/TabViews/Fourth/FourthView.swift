//
//  FourthView.swift
//  TabBasedApplication
//
//  Created by Ritika Verma on 18/04/22.
//

import SwiftUI

struct Teams {
    let name: String
    let logo: String
}

struct FourthView: View {
    
    @State var teamArr = [Teams(name: "Chennai Super Kings", logo: "csk"), Teams(name: "Delhi Capitals", logo: "dc"), Teams(name: "Kolkata Knight Riders", logo: "kkr"), Teams(name: "Mumbai Indians", logo: "mi"), Teams(name: "Kings XI Punjab", logo: "pbks"), Teams(name: "Royal Challengers Bangalore", logo: "rcb"), Teams(name: "Rajasthan Royals", logo: "rr"), Teams(name: "Sunrisers Hyderabad", logo: "srh")]

    var body: some View {
        NavigationView {
            ScrollView(.vertical, showsIndicators: false) {
                ForEach(0..<4) { i in
                    HStack {
                        ForEach(0..<2) { j in
                            CollectionViewCell(team: teamArr[i+j+i]).onTapGesture {
                                print("(\(i),\(j))")
                            }
                        }
                    }
                }
            }.navigationBarTitle("TEAMS")
            Spacer()
        }
    }
}

struct FourthView_Previews: PreviewProvider {
    static var previews: some View {
        FourthView()
    }
}
