//
//  CollectionViewCell.swift
//  TabBasedApplication
//
//  Created by Ritika Verma on 18/04/22.
//

import SwiftUI

struct CollectionViewCell: View {
    
//    static let col = 3
//    static let row = 10
    var team: Teams
    let width = (UIScreen.main.bounds.width/2)-20
    var body: some View {
        VStack {
            ZStack {
//                RoundedRectangle(cornerRadius: 60).foregroundColor(.purple).frame(width: width, height: width, alignment: .center)
                Image(team.logo).resizable().frame(width: width, height: width, alignment: .center).clipShape(Circle())
            }
            Text(team.name).foregroundColor(.purple).font(.body)
        }
    }
}

struct CollectionViewCell_Previews: PreviewProvider {
    static var previews: some View {
        CollectionViewCell(team: Teams(name: "Test", logo: "nature"))
    }
}
