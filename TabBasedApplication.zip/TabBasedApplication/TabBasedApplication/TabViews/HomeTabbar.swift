//
//  HomeTabbar.swift
//  TabBasedApplication
//
//  Created by Ritika Verma on 18/04/22.
//

import SwiftUI

struct HomeTabbar: View {
    
    @State private var defaultView : Int = 0

    var body: some View {
        TabView(selection: $defaultView) {
            FirstView()
                .tabItem {
                    Image(systemName: "1.square.fill")
                }.tag(0)
            SecondView()
                .tabItem {
                    Image(systemName: "2.square.fill")
                }.tag(1)
            ThirdView()
                .tabItem {
                    Image(systemName: "3.square.fill")
                }.tag(2)
            FourthView()
                .tabItem {
                    Image(systemName: "4.square.fill")
                }.tag(3)
            FifthView()
                .tabItem {
                    Image(systemName: "5.square.fill")
                }.tag(4)
        }.accentColor(.purple)
    }
}

struct HomeTabbar_Previews: PreviewProvider {
    static var previews: some View {
        HomeTabbar()
    }
}
